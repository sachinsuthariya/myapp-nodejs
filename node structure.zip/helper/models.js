// imports
const userModel = require("../modules/user/userModel");

const Models = {
    userModel: userModel
};

module.exports = Models;